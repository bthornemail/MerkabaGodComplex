import { HDNodeVoidWallet } from 'ethers';
import { HostWallet ,ProviderWallet} from './data';
import { HDNodeWallet } from 'ethers';
export default async function getLink(signer: HDNodeVoidWallet | HDNodeWallet,link?: string): Promise<string>{
    const location = "http://127.0.0.1:3000"
    //  Click Listeners for user 
    const url = link ? new URL(link,location) : new URL(location);
    HostWallet.publicKey && url.searchParams.set("host", HostWallet.publicKey);
    ProviderWallet.publicKey && url.searchParams.set("provider", ProviderWallet.publicKey);
    signer.publicKey && url.searchParams.set("consumer", signer.publicKey);
    // console.log(url.href)
    // console.debug(url.href)
    // console.log(url)
    return url.href 
}