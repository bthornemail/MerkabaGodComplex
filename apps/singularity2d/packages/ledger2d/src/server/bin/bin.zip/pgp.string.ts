import * as openpgp from 'openpgp';
import { HDNodeWallet } from "ethers";

const masterWallet = HDNodeWallet.fromPhrase("type bullet alley learn crumble now size tube design abstract debate toy", undefined, "m/0")
const HostWallet = HDNodeWallet.fromPhrase("special govern replace virus mistake marriage tail nurse able high garage salmon", undefined, "m/0")

const key1 = masterWallet.signingKey.computeSharedSecret(HostWallet.publicKey)
const key2 = HostWallet.signingKey.computeSharedSecret(masterWallet.publicKey)
console.log(key1, key1 === key2, key2);
(async () => {
    
    // const message = await openpgp.createMessage({ binary: new Uint8Array([0x01, 0x01, 0x01]) });
    const message = await openpgp.createMessage({ text: 'Hello, World!' })
    const encrypted = await openpgp.encrypt({
        message, // input as Message object
        passwords: [key1], // multiple passwords possible
        // format: 'binary' // don't ASCII armor (for Uint8Array output)
    });
    console.log(encrypted); // Uint8Array

    const encryptedMessage = await openpgp.readMessage({
        armoredMessage: encrypted
        // binaryMessage: encrypted // parse encrypted bytes
    });
    const { data: decrypted } = await openpgp.decrypt({
        message: encryptedMessage,
        passwords: [key2], // decrypt with password
        // format: 'binary' // output as Uint8Array
    });
    console.log(decrypted); // Uint8Array([0x01, 0x01, 0x01])
})();