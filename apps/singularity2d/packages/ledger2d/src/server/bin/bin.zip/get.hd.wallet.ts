import { HDNodeWallet } from 'ethers';
import { HDNodeVoidWallet } from 'ethers';

// Generate wallets

// const masterNode: HDNodeWallet = HDNodeWallet.createRandom();
// const mnemonic = masterNode.mnemonic;
// console.log(mnemonic?.phrase)
// const masterWallet = HDNodeWallet.fromMnemonic(masterNode.mnemonic!)
// export const extra_wallet_0 = HDNodeWallet.fromPhrase("fragile chair exile people dragon social emotion squeeze upset practice sniff middle", undefined, "m/0")
// export const extra_wallet_1 = HDNodeWallet.fromPhrase("misery clean step badge evoke current promote measure cram tumble quiz fragile", undefined, "m/0")
export const masterWallet = HDNodeWallet.fromPhrase("type bullet alley learn crumble now size tube design abstract debate toy", undefined, "m/0")
// const MarketplaceWallet = Wallet.fromPhrase(mnemonic?.phrase!)
// const MarketplaceWallet1: HDNodeVoidWallet = Wallet.fromPhrase(mnemonic?.phrase!).neuter()
const numChildWallets = 10;
export const childWallets: HDNodeWallet[] = Array.from(Array(numChildWallets).keys()).map(index => masterWallet.derivePath(`${index}`));

export const MarketplaceWallet = masterWallet;
export const HostWallet = HDNodeWallet.fromPhrase("special govern replace virus mistake marriage tail nurse able high garage salmon", undefined, "m/0")
export const ClientWallet = HDNodeWallet.fromPhrase("sense hybrid relax island palm elbow you want tattoo grape connect cash", undefined, "m/0");
export const ProviderWallet = HDNodeWallet.fromPhrase("dawn gallery history crime knock income blossom catalog piece kiss arrive culture", undefined, "m/0")
export const QuickWheelWashWallet = ProviderWallet.deriveChild(0);
export const WashTypeWallet = QuickWheelWashWallet.deriveChild(0);
export const GlossTypeWallet = QuickWheelWashWallet.deriveChild(1);
export const CleanTypeWallet = QuickWheelWashWallet.deriveChild(2);
export const ScheduledDateWallet = QuickWheelWashWallet.deriveChild(3);
export const ConsumerWallet = HDNodeWallet.fromPhrase("regular about daughter wide autumn pony assault woman treat claim trial supreme", undefined, "m/0")

export const MarketplaceAddress = MarketplaceWallet.address;
export const HostAddress = HostWallet.address;
export const ClientAddress = ClientWallet.address;
export const ProviderAddress = ProviderWallet.address;
export const QuickWheelWashWalletAddress = QuickWheelWashWallet.address;
export const ConsumerAddress = ConsumerWallet.address;

export default "type bullet alley learn crumble now size tube design abstract debate toy"

