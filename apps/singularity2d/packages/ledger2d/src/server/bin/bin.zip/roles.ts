interface User {
    userId: string;
    role: string;
    permissions: string[];
    data: any;
}

type RolePermissions = {
    [role: string]: {
	permissions: string[];
    };
};

const roles: RolePermissions = {
    admin: { permissions: ["read", "write", "delete"] },
    provider: { permissions: ["read", "write"] },
    consumer: { permissions: ["read"] }
};

function hasPermission(user: User, action: string): boolean {
    return user.permissions.includes(action);
}

function readData(user: User) {
    if (hasPermission(user, "read")) {
	console.log("Reading data...");
	// Function logic here
    } else {
	console.log("Permission denied");
    }
}

function writeData(user: User) {
    if (hasPermission(user, "write")) {
	console.log("Writing data...");
	// Function logic here
    } else {
	console.log("Permission denied");
    }
}

function deleteData(user: User) {
    if (hasPermission(user, "delete")) {
	console.log("Deleting data...");
	// Function logic here
    } else {
	console.log("Permission denied");
    }
}

// Example usage
const user: User = {
    userId: "user1",
    role: "provider",
    permissions: roles["provider"].permissions,
    data: {}
};

readData(user);  // Output: Reading data...
writeData(user); // Output: Writing data...
deleteData(user); // Output: Permission denied
