import { HDNodeWallet, id, toBeArray, recoverAddress, SigningKey , toUtf8Bytes} from 'ethers';
import { encryptData } from './pgp';

const wallet = HDNodeWallet.fromPhrase("right zero certain path frame cradle laugh poverty offer west fat trip")
const wallet2 = HDNodeWallet.fromPhrase("satisfy version refuse lunch panel derive almost aunt boil lunch zoo inject")
console.log('Address:', wallet.address);
// console.log('Private Key:', wallet.privateKey);
// console.log('Private Key:', wallet2.mnemonic?.phrase);
console.log('Public Key:', wallet.publicKey);

const walletState = new Map();
const message = "hello world";
const messageHash = id(message); // Hash the message
const messageBytes = toBeArray(messageHash);
walletState.set(messageHash,messageBytes);

let signatureHD = wallet.signingKey.sign(messageBytes).compactSerialized;
let publicKey = SigningKey.computePublicKey(wallet.privateKey);
let peerPublicKey = SigningKey.computePublicKey(wallet2.publicKey);

async function main() {
    const messageEncrypted = await encryptData(messageBytes, wallet.signingKey.computeSharedSecret(peerPublicKey))
    console.log("message", message)
    console.log("messageHash", messageHash)
    console.log("messageHash", messageEncrypted)
    signatureHD = wallet.signingKey.sign(messageHash).compactSerialized;
    console.log('Signature:', signatureHD);
}

async function second() {
    const wallet = HDNodeWallet.fromPhrase("right zero certain path frame cradle laugh poverty offer west fat trip").neuter()
    const wallet2 = HDNodeWallet.fromPhrase("satisfy version refuse lunch panel derive almost aunt boil lunch zoo inject").neuter()

    // console.log("messageHash",messageEncrypted)
    const recoveredAddress = recoverAddress(
        messageHash,
        signatureHD
    );
    const recoveredPublicKey = SigningKey.recoverPublicKey(
        messageHash,
        signatureHD
    );
    console.log('messageHash:', messageHash);
    console.log('Address match:', wallet.address === recoveredAddress, recoveredAddress);
    console.log('Public key match:', publicKey === recoveredPublicKey, recoveredPublicKey);
    console.log(new TextDecoder().decode((walletState.get(messageHash))))
}

main().then(second)