import { ethers } from 'ethers';

// Example mnemonic and path
const mnemonic = 'your mnemonic goes here';
const path = "m/44'/60'/0'/0/0"; // Example path

// Derive the parent key
const parentKey = ethers.Wallet.fromMnemonic(mnemonic).derivePath(path);

// Access the parent fingerprint
const parentFingerprint = parentKey.parentFingerprint;

console.log('Parent Fingerprint:', parentFingerprint);
