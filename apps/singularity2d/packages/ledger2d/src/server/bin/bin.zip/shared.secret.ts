import { HDNodeWallet } from "ethers";

const masterWallet = HDNodeWallet.fromPhrase("type bullet alley learn crumble now size tube design abstract debate toy", undefined, "m/0")
const HostWallet = HDNodeWallet.fromPhrase("special govern replace virus mistake marriage tail nurse able high garage salmon", undefined, "m/0")

const key1 = masterWallet.signingKey.computeSharedSecret(HostWallet.publicKey)
const key2 = HostWallet.signingKey.computeSharedSecret(masterWallet.publicKey)
console.log(key1, key1 === key2, key2)