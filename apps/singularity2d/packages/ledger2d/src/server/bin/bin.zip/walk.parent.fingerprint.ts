import { ethers } from 'ethers';

// Example mnemonic and path
const mnemonic = 'your mnemonic goes here';
const path = "m/44'/60'/0'/0/0"; // Example path

// Initialize the root fingerprint as null
let rootFingerprint: string | null = null;

// Start deriving keys
let key = ethers.HDNodeWallet.fromMnemonic(mnemonic);
let key = ethers.HDNodeWallet.fromMnemonic(mnemonic);

// Derive keys until reaching the root
while (key) {
    // Access the parent fingerprint
    const parentFingerprint = key.parentFingerprint;

    // Check if the parent fingerprint is null
    if (parentFingerprint === '0x00000000') {
        // If parent fingerprint is null, it's the root wallet
        rootFingerprint = key.fingerprint;
        break;
    }

    // Derive the next key
    key = key.derivePath(path);
}

console.log('Root Wallet Fingerprint:', rootFingerprint);
