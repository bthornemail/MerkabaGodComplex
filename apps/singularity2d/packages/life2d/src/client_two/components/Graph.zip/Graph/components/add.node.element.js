function addNodeElement(node) {
    const form = document.createElement('div')
    Object.entries(node).forEach(([key, value]) => {
        let input = document.createElement('input')
        let button = document.createElement('button')
        let formControl = document.createElement('div')
        switch (typeof value) {
            case 'number':
                input.type = 'number'
                break;
            case 'string':
                if (value.length > 30)
                    input = document.createElement('textarea')
                input.innerText = value
            default:
                return;
        }
        form.style.display = 'flex'
        form.style.flexDirection = 'column'
        formControl.classList.add('btn-group')

        button.textContent = key
        button.classList.add('btn')
        button.classList.add('btn-light')
        
        input.name = key
        input.defaultValue = value
        input.classList.add('form-control')
        
        formControl.append(button)
        formControl.append(input)
        form.append(formControl)
    })
    return form
}