
import { BrowserRouter} from 'react-router-dom';
import Marketplace from './Marketplace';
import './App.css';

function App() {
  return (
      <BrowserRouter>
        {/* <div className="app"> */}
          <Marketplace/>
        {/* </div> */}
      </BrowserRouter>
  );
}


export default App;
